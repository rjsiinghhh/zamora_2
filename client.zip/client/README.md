________________________________________________________

Take a look at the zamoraProject frontend OVER HERE!!!!
https://zamoraproject.netlify.app/ 


________________________________________________________


The ZamoraProject is based around the idea of helping. Either Zamora is collecting posts from one worker to show the others, or you can scroll through the chart that visuales all the finacial aspecrs of the land. Now thinking about the project from a different view, I plan on spliting the project into a workers type structure and an owner/ leader strucure.  It's obvious now, workers shouldnt see finaces at all. So now, user auth needs to be put in play, but in a different type of way. Uppn entering the site, you should see a small login section. Accrding to the number you input you will either be welcomed as a worker(WHO WILL ACCESS TO THE DAILY SCHEDULE, MAP, PRETTY ANYTHING OR EVERYTHING THAT IS APPROPREIATE FOR A STAFF MEMEBER TO SEE). As for the other login, it will generally be set up for one, two, three, or however many owners/leaders of the property there are. Inm my mind the ratio of owners/ management to workers is probaoy 2 : 30 people/ The levels of workers also chage, of course these staff members need to have more access than the base level employees. THat will be next piece to the puzzle that needs to be solved. Making this project usable and actually understandable for the workers who arent the most tech savy and the ones who dont speak english is a goal that is obtainable. By makiung the UI of Zamora simple but effective, this idea will be used and tested in a real setting. 


Now, away from the new ideas, I was able to get theont end deplyed. It runs, but there are bugs and since React router is what was used. Eveytime ,it soon goes to a 404 after you RE click what ever route you to see. 


