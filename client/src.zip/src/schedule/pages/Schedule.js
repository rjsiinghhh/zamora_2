import React, { Fragment } from 'react';
import './Schedule.css';
import Add from '../components/timeline/Add'
import Timeline from '../components/timeline/Timeline'

const Schedule = props => {
    return ( < >
        <
        Fragment >

        <
        Add / >
        <
        Timeline / >
        <
        /Fragment>

        <
        />
    )
}

export default Schedule;