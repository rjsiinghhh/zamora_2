let timelineElements = [
    {
      description:
        "Need to do that one thing.",
      date: "Jan 15, 2021",
      icon: "work",
    },
    {
      description:
        "And that other thing.",
      date: "Jan 15, 2021",
      icon: "work",
    },
    {
      description:
        "ohhh and the other one too",
      date: "Jan 16 2021",
      icon: "work",
    },
    {
      description:
        "need to get the back end set up with this tooooo",
      date: "Jan 17, 2021",
      icon: "work",
    },
    {
      description:
        "and the d3 chart and ",
      date: "Jan 18, 2021",
      icon: "work",
    },
    {
      description:
        "the finance section needs a little table with that.",
      date: "Jan 21, 2021",
      icon: "work",
    },
  ];
  
  export default timelineElements;